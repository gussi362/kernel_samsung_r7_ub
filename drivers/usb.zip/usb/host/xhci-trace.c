/*
 * xHCI host controller driver
 *
 * Copyright (C) 2013 Xenia Ragiadakou
 *
 * Author: Xenia Ragiadakou
 * Email : burzalodowa@gmail.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#define CREATE_TRACE_POINTS
#include "xhci-trace.h"

EXPORT_TRACEPOINT_SYMBOL_GPL(xhci_dbg_quirks);
