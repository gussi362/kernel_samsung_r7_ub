#ifndef TIMA_UEVENT_H
#define TIMA_UEVENT_H

#define TIMA_UEVENT_DEV     "tima_uevent"

extern int dm_uevent_init(void);
extern void dm_uevent_exit(void);

#endif	/* TIMA_UEVENT_H */
