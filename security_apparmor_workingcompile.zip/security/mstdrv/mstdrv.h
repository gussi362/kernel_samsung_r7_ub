#ifndef MST_DRV_H
#define MST_DRV_H

#define MST_DRV_DEV     "mst_drv"

#endif /* MST_FTMDRV_H */
